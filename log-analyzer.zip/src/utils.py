
def print_summary(alerts):
    print(f"\nDetected {len(alerts)} potential threat(s):")
    for alert in alerts:
        print(f"- {alert['type']} from IP {alert['ip']} ({alert['count']} attempts)")
