
import re

def parse_log_line(line):
    pattern = r'(?P<ip>\d+\.\d+\.\d+\.\d+) - - \[(?P<timestamp>.*?)\] "(?P<request>.*?)" (?P<status>\d{3}) (?P<size>\d+|-)'
    match = re.match(pattern, line)
    if match:
        return match.groupdict()
    return None

def load_logs(filepath):
    with open(filepath, 'r') as file:
        return [parse_log_line(line.strip()) for line in file if parse_log_line(line)]
