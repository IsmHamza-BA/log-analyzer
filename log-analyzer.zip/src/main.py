
from parser import load_logs
from analyzer import detect_brute_force
from alerting import save_alerts
from utils import print_summary

def main():
    logs = load_logs("sample_logs/access_log.txt")
    if not logs:
        print("[-] No logs to analyze.")
        return

    alerts = detect_brute_force(logs)
    print_summary(alerts)
    if alerts:
        save_alerts(alerts)

if __name__ == "__main__":
    main()
