
import json
from datetime import datetime

def save_alerts(alerts, output_dir="reports"):
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"{output_dir}/alerts_{timestamp}.json"
    with open(filename, 'w') as f:
        json.dump(alerts, f, indent=4)
    print(f"[+] Alerts saved to {filename}")
