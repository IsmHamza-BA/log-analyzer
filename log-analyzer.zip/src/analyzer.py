
from collections import defaultdict
from datetime import datetime, timedelta

def detect_brute_force(logs, threshold=5, interval_minutes=1):
    ip_failed_attempts = defaultdict(list)
    alerts = []

    for entry in logs:
        if entry['status'] == '401':
            timestamp = datetime.strptime(entry['timestamp'], '%d/%b/%Y:%H:%M:%S %z')
            ip_failed_attempts[entry['ip']].append(timestamp)

    for ip, attempts in ip_failed_attempts.items():
        attempts.sort()
        for i in range(len(attempts) - threshold + 1):
            if (attempts[i + threshold - 1] - attempts[i]) <= timedelta(minutes=interval_minutes):
                alerts.append({
                    "ip": ip,
                    "type": "Brute Force",
                    "count": threshold,
                    "time_range": f"{attempts[i]} - {attempts[i + threshold - 1]}"
                })
                break
    return alerts
