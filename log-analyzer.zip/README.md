# Log Analyzer

A Python-based tool to parse, analyze, and detect suspicious activity in server logs.
